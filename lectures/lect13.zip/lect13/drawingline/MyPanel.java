package lect13.drawingline;

import javax.swing.*;
import java.awt.*;

public class MyPanel extends JPanel {
    @Override
    public void paintComponent(Graphics g) {
        g.setColor(Color.RED);
        g.drawLine(60, 30, 300, 90);
    }
}
