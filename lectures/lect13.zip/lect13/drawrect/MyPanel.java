package lect13.drawrect;

import javax.swing.*;
import java.awt.*;

public class MyPanel extends JPanel {
    @Override
    public void paintComponent(Graphics g) {
        g.setColor(Color.BLUE);
        g.drawRect(100, 50, 300, 200);
    }
}
