package lect13.text;

import javax.swing.*;
import java.awt.*;

public class MyPanel extends JPanel {
    @Override
    public void paintComponent(Graphics g) {
        g.setColor(Color.BLUE);
        Font f = new Font("Arial", Font.ITALIC, 60);
        g.setFont(f);
        g.drawString("Hello world!", 20, 100);
    }
}
