package lect13.oval;

import javax.swing.*;
import java.awt.*;

public class MyPanel extends JPanel {
    @Override
    public void paintComponent(Graphics g) {
        g.setColor(Color.BLUE);
        g.drawOval(10, 10, 90, 90);
        g.fillOval(300, 30, 150, 105);
    }
}
