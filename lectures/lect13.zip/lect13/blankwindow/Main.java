package lect13.blankwindow;

import javax.swing.*;
import java.awt.*;

public class Main {
    public static void main(String[] args) {
        JFrame f = new JFrame("JFrame demo");
        JPanel p = new MyPanel();
        f.setSize(480, 360);
        f.add(p, BorderLayout.CENTER);
        f.setLocationRelativeTo(null); // center the frame
        // make the program terminate when window closes
        f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        f.setVisible(true); // make the window visible
    }
}
