package lect13.blankwindow;

import javax.swing.JPanel;
import java.awt.Graphics;

public class MyPanel extends JPanel {
    @Override
    public void paintComponent(Graphics g) {

    }
}
