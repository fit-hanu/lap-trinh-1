package lect13.animate;

import javax.swing.*;
import java.awt.*;

public class Main {
    public static void main(String[] args) throws InterruptedException {
        JFrame f = new JFrame("Animating an Image");
        JPanel p = new MyPanel();
        f.setSize(480, 360);
        f.add(p, BorderLayout.CENTER);
        f.setLocationRelativeTo(null); // center the frame
        // make the program terminate when window closes
        f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        f.setVisible(true); // make the window visible
        int n = 0;
        while (n < 100) {
            Thread.sleep(30);
            p.repaint();
            n++;
        }
    }
}
