package lect13.animate;

import javax.imageio.ImageIO;
import javax.swing.*;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;

public class MyPanel extends JPanel {

    BufferedImage img = null;
    int x = 0, y = 0;

    public MyPanel() {
        super();
        File imgFile = new File("images/ava2.jpg");
        try {
            img = ImageIO.read(imgFile);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    @Override
    public void paintComponent(Graphics g) {
        g.clearRect(0, 0, getWidth(), getHeight());
        g.drawImage(img, x, y, null);
        x += 1;
        y += 1;
    }
}
