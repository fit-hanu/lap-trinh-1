package lect13.image;

import javax.imageio.ImageIO;
import javax.swing.*;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;

public class MyPanel extends JPanel {
    @Override
    public void paintComponent(Graphics g) {
        File imgFile = new File("images/ava2.jpg");
        try {
            BufferedImage img = ImageIO.read(imgFile);
            int x = img.getWidth() / 2;
            int y = img.getHeight() / 2;
            x = (getWidth() / 2) - x;
            y = (getHeight() / 2) - y;
            g.drawImage(img, x, y, null);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }
}
